-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: restaurant_db
-- ------------------------------------------------------
-- Server version	9.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dishes`
--

DROP TABLE IF EXISTS `dishes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dishes` (
  `dish_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL,
  `category` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`dish_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dishes`
--

LOCK TABLES `dishes` WRITE;
/*!40000 ALTER TABLE `dishes` DISABLE KEYS */;
INSERT INTO `dishes` VALUES (1,'כנפי עוף מעושנות','כנפיים מעושנות עם רוטב צ\'ילי מתוק',49.00,'מנות פתיחה','assets/img/18.jpg',1,'2025-06-20 09:28:32'),(2,'באן אסדו','בנאים ממולאים בבשר אסדו, רוטב איולי',58.00,'מנות פתיחה','assets/img/10.webp',1,'2025-06-20 09:28:32'),(3,'פוקאצ\'ת הבית','פוקאצ\'ה חמה מהתנור עם שמן זית',38.00,'מנות פתיחה','assets/img/20.jpg',1,'2025-06-20 09:28:32'),(4,'סיגר בשר','עלי סיגר ממולאים בבשר עם רטבי הבית',53.00,'מנות פתיחה','assets/img/11.jpg',1,'2025-06-20 09:28:32'),(5,'קרפצ\'יו בקר','נתחי פילה דקים עם סילאן וברוסקטות',35.00,'מנות פתיחה','assets/img/35.jpeg',1,'2025-06-20 09:28:32'),(6,'חומוס בשר','חומוס עם בשר, פטריות, גרגרים ופיתות',59.00,'מנות פתיחה','assets/img/36.webp',1,'2025-06-20 09:28:32'),(7,'המבורגר אנגוס','250 גרם אנגוס, תוספות לבחירה',78.00,'מנות עיקריות','assets/img/6.png',1,'2025-06-20 09:28:32'),(8,'צלעות טלה','צלעות טלה עם רוטב יין אדום',145.00,'מנות עיקריות','assets/img/9.webp',1,'2025-06-20 09:28:32'),(9,'פרגית צלויה','סטייק פרגית עם תפוחי אדמה ואספרגוס',82.00,'מנות עיקריות','assets/img/21.jpg',1,'2025-06-20 09:28:32'),(10,'סטייק אנטריקוט','נתח אנטריקוט 350 גרם עם ירקות צלויים',165.00,'סטייקים','assets/img/14.jpg',1,'2025-06-20 09:28:32'),(11,'פילה בקר','250 גרם פילה בקר עם רוטב יין אדום',182.00,'סטייקים','assets/img/22.jpg',1,'2025-06-20 09:28:32'),(12,'טומהוק','סטייק גרזן 800 גרם עם שני רטבים',320.00,'סטייקים','assets/img/23.webp',1,'2025-06-20 09:28:32'),(13,'תפוחי אדמה צלויים','עם שום ורוזמרין',32.00,'תוספות','assets/img/24.jpg',1,'2025-06-20 09:28:32'),(14,'ירקות צלויים','ירקות עונתיים עם שמן זית ותבלינים',38.00,'תוספות','assets/img/26.webp',1,'2025-06-20 09:28:32'),(15,'צ\'יפס אמיתי','צ\'יפס טרי עם רטבי הבית',42.00,'תוספות','assets/img/25.webp',1,'2025-06-20 09:28:32'),(16,'סופלה שוקולד','סופלה חם עם כדור גלידת וניל',48.00,'קינוחים','assets/img/27.jpg',1,'2025-06-20 09:28:32'),(17,'פבלובת תותים','עוגת פבלובה פרותית',42.00,'קינוחים','assets/img/29.jpg',1,'2025-06-20 09:28:32'),(18,'קרם ברולה','קרם וניל עם שכבת קרמל פריך',44.00,'קינוחים','assets/img/28.webp',1,'2025-06-20 09:28:32'),(19,'משקאות מוגזים','קולה, קולה זירו, פנטה, שוופס',15.00,'משקאות','assets/img/32.webp',1,'2025-06-20 09:28:32'),(20,'משקאות קלים','תפוזים, ענבים, לימונענע, מים בטעמים',12.00,'משקאות','assets/img/33.jpg',1,'2025-06-20 09:28:32'),(21,'שייקים פרווה','לימונענע, מנגו, תות, פציפלורה',18.00,'משקאות','assets/img/34.webp',1,'2025-06-20 09:28:32'),(22,'בקבוק יין','מבחר יינות אדומים - שאל את המלצר',120.00,'משקאות','assets/img/31.jpeg',1,'2025-06-20 09:28:32'),(23,'קוקטיילים','מבחר קוקטיילים מיוחדים',52.00,'משקאות','assets/img/16.webp',1,'2025-06-20 09:28:32'),(24,'בירה מהחבית','שליש/חצי בירה מהחבית',32.00,'משקאות','assets/img/30.jpg',1,'2025-06-20 09:28:32');
/*!40000 ALTER TABLE `dishes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-26 17:20:57
